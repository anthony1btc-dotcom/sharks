const V='sharks-v19';
self.addEventListener('install',e=>{self.skipWaiting();});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{const u=e.request.url;if(u.includes('firebase')||u.includes('anthropic')||u.includes('googleapis')||u.includes('gstatic')||u.includes('openai')||u.includes('generativelanguage')||u.includes('groq')||u.includes('fonts.')||u.includes('tradingview'))return;e.respondWith(fetch(e.request).catch(()=>new Response('',{status:503})));});